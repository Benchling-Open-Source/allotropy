from allotropy.__about__ import __version__

ASM_CONVERTER_NAME = "allotropy"
ASM_CONVERTER_VERSION = __version__
